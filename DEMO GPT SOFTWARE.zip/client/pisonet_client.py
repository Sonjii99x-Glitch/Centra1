#!/usr/bin/env python3
"""
PisoNet Client - Windows PyQt5 Application
Floating timer UI that connects to the server
"""

import sys
import os
import json
import socket
import uuid
import requests
import time
import logging
from datetime import datetime, timedelta
from pathlib import Path
from configparser import ConfigParser

from PyQt5.QtWidgets import (
    QApplication, QWidget, QVBoxLayout, QHBoxLayout, 
    QLabel, QPushButton, QMessageBox, QSystemTrayIcon, QMenu,
    QInputDialog, QLineEdit, QSpinBox
)
from PyQt5.QtCore import Qt, QTimer, QThread, pyqtSignal
from PyQt5.QtGui import QFont, QIcon, QColor, QPalette

# ============================================================================
# CONFIGURATION
# ============================================================================

# Paths
APPDATA_PATH = Path(os.environ.get('APPDATA')) / 'PisoNet'
CONFIG_FILE = APPDATA_PATH / 'client_config.ini'
LOG_FILE = APPDATA_PATH / 'client.log'

# Create directories
APPDATA_PATH.mkdir(parents=True, exist_ok=True)

# ============================================================================
# LOGGING
# ============================================================================

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler(LOG_FILE),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

# ============================================================================
# CONFIGURATION MANAGER
# ============================================================================

class ConfigManager:
    def __init__(self, config_file):
        self.config_file = config_file
        self.config = ConfigParser()
        self.load_config()

    def load_config(self):
        if self.config_file.exists():
            self.config.read(self.config_file)
        else:
            self.create_default_config()

    def create_default_config(self):
        self.config['Server'] = {
            'server_ip': '192.168.1.100',
            'server_port': '5000',
            'server_hostname': 'pisonet.local'
        }
        self.config['Client'] = {
            'client_name': f'Workstation-{uuid.getnode() % 10000}',
            'check_interval': '1'
        }
        self.config['UI'] = {
            'timer_x': '10',
            'timer_y': '10',
            'timer_width': '300',
            'timer_height': '150',
            'transparency': '0.9'
        }
        self.save_config()

    def save_config(self):
        self.config_file.parent.mkdir(parents=True, exist_ok=True)
        with open(self.config_file, 'w') as f:
            self.config.write(f)

    def get(self, section, key, default=None):
        try:
            return self.config.get(section, key)
        except:
            return default

    def set(self, section, key, value):
        if not self.config.has_section(section):
            self.config.add_section(section)
        self.config.set(section, key, str(value))
        self.save_config()

# ============================================================================
# CLIENT COMMUNICATOR (Background Thread)
# ============================================================================

class ClientCommunicator(QThread):
    """Handles server communication in background thread"""
    
    status_changed = pyqtSignal(dict)
    error_occurred = pyqtSignal(str)

    def __init__(self, server_url, client_id, client_name, check_interval=1):
        super().__init__()
        self.server_url = server_url
        self.client_id = client_id
        self.client_name = client_name
        self.check_interval = float(check_interval)
        self.running = True
        self.registered = False

    def run(self):
        """Main thread loop"""
        self.register_client()
        
        while self.running:
            try:
                self.sync_with_server()
            except Exception as e:
                logger.error(f"Sync error: {e}")
                self.error_occurred.emit(f"Sync error: {e}")
            
            time.sleep(self.check_interval)

    def register_client(self):
        """Register client with server"""
        try:
            mac = uuid.getnode()
            mac_str = ':'.join(('%012x' % mac)[i:i+2] for i in range(0, 12, 2))

            response = requests.post(
                f'{self.server_url}/api/register',
                json={
                    'client_id': self.client_id,
                    'name': self.client_name,
                    'mac_address': mac_str
                },
                timeout=5
            )

            if response.status_code == 200:
                data = response.json()
                if data.get('success'):
                    self.registered = True
                    logger.info(f"Client registered: {self.client_id}")
                    self.status_changed.emit({'registered': True})
            else:
                raise Exception(f"Registration failed: {response.status_code}")
        except Exception as e:
            logger.error(f"Registration error: {e}")
            self.error_occurred.emit(f"Cannot reach server: {e}")

    def sync_with_server(self):
        """Sync client state with server"""
        if not self.registered:
            return

        try:
            response = requests.get(
                f'{self.server_url}/api/client/{self.client_id}',
                timeout=5
            )

            if response.status_code == 200:
                client_data = response.json()
                self.status_changed.emit(client_data)
        except Exception as e:
            logger.debug(f"Sync error: {e}")

    def add_time(self, minutes):
        """Request time addition from server"""
        try:
            response = requests.post(
                f'{self.server_url}/api/client/{self.client_id}/add-time',
                json={'minutes': minutes},
                timeout=5
            )
            if response.status_code == 200:
                logger.info(f"Added {minutes} minutes")
                self.sync_with_server()
        except Exception as e:
            logger.error(f"Add time error: {e}")

    def stop(self):
        """Stop the thread"""
        self.running = False
        self.wait()

# ============================================================================
# MAIN TIMER WIDGET
# ============================================================================

class TimerWidget(QWidget):
    """Floating timer window"""

    def __init__(self, config):
        super().__init__()
        self.config = config
        self.client_id = str(uuid.uuid4())
        self.client_name = config.get('Client', 'client_name', f'Workstation-{uuid.getnode() % 10000}')
        self.remaining_time = 0
        self.total_time = 0
        
        # Server configuration
        try:
            # Try hostname first
            hostname = config.get('Server', 'server_hostname', 'pisonet.local')
            ip = socket.gethostbyname(hostname)
            logger.info(f"Resolved {hostname} to {ip}")
        except:
            # Fallback to IP
            ip = config.get('Server', 'server_ip', '192.168.1.100')
            logger.warning(f"Could not resolve hostname, using IP: {ip}")

        port = config.get('Server', 'server_port', '5000')
        self.server_url = f'http://{ip}:{port}'

        logger.info(f"Server URL: {self.server_url}")
        logger.info(f"Client ID: {self.client_id}")
        logger.info(f"Client Name: {self.client_name}")

        self.init_ui()
        self.start_communicator()
        self.start_update_timer()

    def init_ui(self):
        """Initialize UI"""
        # Main layout
        layout = QVBoxLayout()
        layout.setContentsMargins(10, 10, 10, 10)
        layout.setSpacing(10)

        # Timer display
        self.timer_label = QLabel('00:00:00')
        font = QFont()
        font.setPointSize(48)
        font.setBold(True)
        self.timer_label.setFont(font)
        self.timer_label.setAlignment(Qt.AlignCenter)
        layout.addWidget(self.timer_label)

        # Client name
        self.name_label = QLabel(self.client_name)
        name_font = QFont()
        name_font.setPointSize(10)
        self.name_label.setFont(name_font)
        self.name_label.setAlignment(Qt.AlignCenter)
        self.name_label.setStyleSheet('color: #999;')
        layout.addWidget(self.name_label)

        # Buttons layout
        buttons_layout = QHBoxLayout()
        
        # Add time button
        self.add_time_btn = QPushButton('+1 min')
        self.add_time_btn.clicked.connect(self.on_add_time)
        buttons_layout.addWidget(self.add_time_btn)

        # Add more time button
        self.add_more_btn = QPushButton('+30 min')
        self.add_more_btn.clicked.connect(lambda: self.add_time(30))
        buttons_layout.addWidget(self.add_more_btn)

        layout.addLayout(buttons_layout)

        # Status label
        self.status_label = QLabel('Connecting...')
        status_font = QFont()
        status_font.setPointSize(8)
        self.status_label.setFont(status_font)
        self.status_label.setAlignment(Qt.AlignCenter)
        self.status_label.setStyleSheet('color: #f90;')
        layout.addWidget(self.status_label)

        self.setLayout(layout)

        # Window settings
        self.setWindowTitle('🪙 PisoNet Timer')
        self.setWindowFlags(Qt.Window | Qt.WindowStaysOnTopHint | Qt.FramelessWindowHint)
        
        # Load size and position
        try:
            x = int(self.config.get('UI', 'timer_x', '10'))
            y = int(self.config.get('UI', 'timer_y', '10'))
            w = int(self.config.get('UI', 'timer_width', '300'))
            h = int(self.config.get('UI', 'timer_height', '150'))
            self.setGeometry(x, y, w, h)
        except:
            self.setGeometry(10, 10, 300, 150)

        # Transparency
        try:
            transparency = float(self.config.get('UI', 'transparency', '0.9'))
            self.setWindowOpacity(transparency)
        except:
            self.setWindowOpacity(0.9)

        # Color scheme
        self.setup_colors()

    def setup_colors(self):
        """Setup color scheme"""
        palette = QPalette()
        palette.setColor(QPalette.Window, QColor(240, 240, 240))
        palette.setColor(QPalette.WindowText, QColor(50, 50, 50))
        self.setPalette(palette)
        self.setAutoFillBackground(True)

    def start_communicator(self):
        """Start background communicator thread"""
        check_interval = self.config.get('Client', 'check_interval', '1')
        self.communicator = ClientCommunicator(
            self.server_url,
            self.client_id,
            self.client_name,
            check_interval
        )
        self.communicator.status_changed.connect(self.on_status_changed)
        self.communicator.error_occurred.connect(self.on_error)
        self.communicator.start()

    def start_update_timer(self):
        """Start UI update timer"""
        self.ui_timer = QTimer()
        self.ui_timer.timeout.connect(self.update_display)
        self.ui_timer.start(100)  # Update every 100ms

    def on_status_changed(self, data):
        """Handle status changes from server"""
        self.remaining_time = data.get('remaining_time', 0)
        self.total_time = data.get('total_time', 0)
        
        status = data.get('status', 'unknown')
        if status == 'active':
            self.status_label.setText('🟢 Active')
            self.status_label.setStyleSheet('color: #27ae60;')
        else:
            self.status_label.setText('⚪ Idle')
            self.status_label.setStyleSheet('color: #7f8c8d;')

    def on_error(self, error):
        """Handle errors"""
        logger.error(error)
        self.status_label.setText(f'❌ Error: {error[:30]}...')
        self.status_label.setStyleSheet('color: #e74c3c;')

    def update_display(self):
        """Update timer display"""
        hours = self.remaining_time // 3600
        minutes = (self.remaining_time % 3600) // 60
        seconds = self.remaining_time % 60

        time_str = f'{hours:02d}:{minutes:02d}:{seconds:02d}'
        self.timer_label.setText(time_str)

        # Change color based on time
        if self.remaining_time <= 0:
            self.timer_label.setStyleSheet('color: #e74c3c;')  # Red
        elif self.remaining_time <= 300:
            self.timer_label.setStyleSheet('color: #f39c12;')  # Orange
        else:
            self.timer_label.setStyleSheet('color: #27ae60;')  # Green

    def on_add_time(self):
        """Handle add time button"""
        self.add_time(1)

    def add_time(self, minutes):
        """Request to add time"""
        logger.info(f"Requesting {minutes} minutes")
        self.communicator.add_time(minutes)

    def closeEvent(self, event):
        """Handle close event"""
        # Save window position
        self.config.set('UI', 'timer_x', self.x())
        self.config.set('UI', 'timer_y', self.y())
        self.config.set('UI', 'timer_width', self.width())
        self.config.set('UI', 'timer_height', self.height())
        
        self.communicator.stop()
        super().closeEvent(event)

    def changeEvent(self, event):
        """Handle minimize to tray"""
        if event.type() == 2:  # QEvent.WindowStateChange
            if self.isMinimized():
                self.hide()
                event.ignore()

# ============================================================================
# MAIN APPLICATION
# ============================================================================

class PisoNetClient(QApplication):
    """Main application"""

    def __init__(self, argv):
        super().__init__(argv)
        self.setApplicationName('PisoNet Client')
        self.setApplicationVersion('1.0.0')

        # Load configuration
        self.config = ConfigManager(CONFIG_FILE)

        # Create main window
        self.timer_widget = TimerWidget(self.config)
        self.timer_widget.show()

        logger.info("PisoNet Client started")

    def closeEvent(self, event):
        """Handle application close"""
        logger.info("PisoNet Client closing")
        super().closeEvent(event)

# ============================================================================
# ENTRY POINT
# ============================================================================

if __name__ == '__main__':
    logger.info("=" * 60)
    logger.info("🪙 PisoNet Client Starting...")
    logger.info("=" * 60)

    app = PisoNetClient(sys.argv)
    sys.exit(app.exec_())
