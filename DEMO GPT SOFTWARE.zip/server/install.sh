#!/bin/bash

# PisoNet Server Installation Script
# Runs on Orange Pi/Raspberry Pi
# This script will install all dependencies and set up the system

set -e

echo "==========================================="
echo "🪙 PisoNet Server Installation"
echo "==========================================="

# Check if running as root
if [[ $EUID -ne 0 ]]; then
   echo "This script must be run as root"
   sudo "$0" "$@"
   exit $?
fi

echo "[1/6] Updating system packages..."
apt-get update
apt-get upgrade -y

echo "[2/6] Installing Python and dependencies..."
apt-get install -y python3 python3-pip python3-dev
apt-get install -y git curl wget

echo "[3/6] Installing GPIO library..."
pip3 install RPi.GPIO Flask Flask-CORS

echo "[4/6] Creating PisoNet directories..."
mkdir -p /var/lib/pisonet
mkdir -p /var/log/pisonet
mkdir -p /opt/pisonet

echo "[5/6] Setting up systemd service..."
cat > /etc/systemd/system/pisonet.service << 'EOF'
[Unit]
Description=PisoNet Server
After=network.target

[Service]
Type=simple
User=root
WorkingDirectory=/opt/pisonet
ExecStart=/usr/bin/python3 /opt/pisonet/pisonet_server.py
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
EOF

echo "[6/6] Enabling and starting service..."
systemctl daemon-reload
systemctl enable pisonet
systemctl restart pisonet

echo ""
echo "==========================================="
echo "✅ Installation Complete!"
echo "==========================================="
echo ""
echo "Server is running at: http://pisonet.local:5000"
echo "Default login: admin / admin123"
echo ""
echo "View logs:"
echo "  sudo journalctl -u pisonet -f"
echo ""
echo "To stop server:"
echo "  sudo systemctl stop pisonet"
echo ""
echo "To view status:"
echo "  sudo systemctl status pisonet"
echo ""
