#!/usr/bin/env python3
"""
PisoNet Server - Main application
Runs on Orange Pi/Raspberry Pi
Manages clients, GPIO, licensing, and web dashboard
"""

import os
import sys
import json
import sqlite3
import hashlib
import threading
import socket
import time
import logging
from datetime import datetime, timedelta
from pathlib import Path
from functools import wraps

from flask import Flask, render_template, request, jsonify, session, redirect, url_for
from flask_cors import CORS
import RPi.GPIO as GPIO

# ============================================================================
# CONFIGURATION
# ============================================================================

SERVER_IP = "0.0.0.0"
SERVER_PORT = 5000
HOSTNAME = "pisonet.local"

# GPIO Configuration
COIN_INPUT_PIN = 3
RELAY_OUTPUT_PIN = 5

# Trial Mode (if no valid license)
TRIAL_MAX_CLIENTS = 2
TRIAL_MAX_MINUTES = 30

# Paths
DB_PATH = "/var/lib/pisonet/pisonet.db"
LICENSE_PATH = "/var/lib/pisonet/license.key"
LOG_PATH = "/var/log/pisonet/server.log"

# Create directories
Path("/var/lib/pisonet").mkdir(parents=True, exist_ok=True)
Path("/var/log/pisonet").mkdir(parents=True, exist_ok=True)

# ============================================================================
# LOGGING
# ============================================================================

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler(LOG_PATH),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

# ============================================================================
# FLASK APP
# ============================================================================

app = Flask(__name__)
app.secret_key = 'pisonet-secret-key-2024'
CORS(app)

# ============================================================================
# DATABASE MANAGER
# ============================================================================

class DatabaseManager:
    def __init__(self, db_path):
        self.db_path = db_path
        self.init_db()

    def get_connection(self):
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        return conn

    def init_db(self):
        conn = self.get_connection()
        cursor = conn.cursor()
        
        # Clients table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS clients (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                client_id TEXT UNIQUE NOT NULL,
                name TEXT NOT NULL,
                ip_address TEXT,
                mac_address TEXT,
                total_time INTEGER DEFAULT 0,
                remaining_time INTEGER DEFAULT 0,
                status TEXT DEFAULT 'idle',
                last_seen TIMESTAMP,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        
        # Sessions table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS sessions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                client_id TEXT NOT NULL,
                start_time TIMESTAMP,
                end_time TIMESTAMP,
                duration INTEGER,
                cost REAL DEFAULT 0,
                FOREIGN KEY (client_id) REFERENCES clients(client_id)
            )
        ''')
        
        # Transactions table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS transactions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                client_id TEXT NOT NULL,
                amount REAL,
                type TEXT,
                timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (client_id) REFERENCES clients(client_id)
            )
        ''')
        
        # Settings table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS settings (
                key TEXT PRIMARY KEY,
                value TEXT
            )
        ''')
        
        conn.commit()
        conn.close()

    def register_client(self, client_id, name, ip_address, mac_address):
        conn = self.get_connection()
        cursor = conn.cursor()
        try:
            cursor.execute('''
                INSERT OR IGNORE INTO clients 
                (client_id, name, ip_address, mac_address, status, last_seen)
                VALUES (?, ?, ?, ?, 'idle', CURRENT_TIMESTAMP)
            ''', (client_id, name, ip_address, mac_address))
            conn.commit()
            return True
        except Exception as e:
            logger.error(f"Error registering client: {e}")
            return False
        finally:
            conn.close()

    def get_all_clients(self):
        conn = self.get_connection()
        cursor = conn.cursor()
        cursor.execute('SELECT * FROM clients')
        clients = [dict(row) for row in cursor.fetchall()]
        conn.close()
        return clients

    def get_client(self, client_id):
        conn = self.get_connection()
        cursor = conn.cursor()
        cursor.execute('SELECT * FROM clients WHERE client_id = ?', (client_id,))
        result = cursor.fetchone()
        conn.close()
        return dict(result) if result else None

    def update_client_time(self, client_id, additional_minutes):
        conn = self.get_connection()
        cursor = conn.cursor()
        cursor.execute('''
            UPDATE clients 
            SET remaining_time = remaining_time + ?,
                total_time = total_time + ?,
                last_seen = CURRENT_TIMESTAMP
            WHERE client_id = ?
        ''', (additional_minutes * 60, additional_minutes * 60, client_id))
        conn.commit()
        conn.close()

    def add_transaction(self, client_id, amount, tx_type):
        conn = self.get_connection()
        cursor = conn.cursor()
        cursor.execute('''
            INSERT INTO transactions (client_id, amount, type)
            VALUES (?, ?, ?)
        ''', (client_id, amount, tx_type))
        conn.commit()
        conn.close()

db_manager = DatabaseManager(DB_PATH)

# ============================================================================
# GPIO CONTROLLER
# ============================================================================

class GPIOController:
    def __init__(self, coin_pin, relay_pin):
        self.coin_pin = coin_pin
        self.relay_pin = relay_pin
        self.coin_detected = False
        self.relay_active = False
        self.init_gpio()
        self.start_coin_listener()

    def init_gpio(self):
        try:
            GPIO.setmode(GPIO.BCM)
            GPIO.setwarnings(False)
            
            # Coin input (input)
            GPIO.setup(self.coin_pin, GPIO.IN, pull_up_down=GPIO.PUD_DOWN)
            
            # Relay output (output)
            GPIO.setup(self.relay_pin, GPIO.OUT)
            GPIO.output(self.relay_pin, GPIO.LOW)
            
            logger.info("GPIO initialized successfully")
        except Exception as e:
            logger.error(f"GPIO initialization error: {e}")

    def start_coin_listener(self):
        """Listen for coin insertions in background"""
        def listen():
            prev_state = GPIO.input(self.coin_pin)
            while True:
                try:
                    current_state = GPIO.input(self.coin_pin)
                    if current_state != prev_state and current_state == GPIO.HIGH:
                        self.on_coin_detected()
                    prev_state = current_state
                    time.sleep(0.1)
                except Exception as e:
                    logger.error(f"Coin listener error: {e}")
                    time.sleep(1)
        
        thread = threading.Thread(target=listen, daemon=True)
        thread.start()

    def on_coin_detected(self):
        """Handle coin detection"""
        logger.info("💰 Coin detected!")
        self.coin_detected = True
        self.relay_on()
        time.sleep(2)  # Keep relay on for 2 seconds
        self.relay_off()
        self.coin_detected = False

    def relay_on(self):
        """Activate relay"""
        try:
            GPIO.output(self.relay_pin, GPIO.HIGH)
            self.relay_active = True
            logger.info("🔌 Relay ON")
        except Exception as e:
            logger.error(f"Relay ON error: {e}")

    def relay_off(self):
        """Deactivate relay"""
        try:
            GPIO.output(self.relay_pin, GPIO.LOW)
            self.relay_active = False
            logger.info("🔌 Relay OFF")
        except Exception as e:
            logger.error(f"Relay OFF error: {e}")

    def get_status(self):
        return {
            'coin_detected': self.coin_detected,
            'relay_active': self.relay_active,
            'coin_pin': self.coin_pin,
            'relay_pin': self.relay_pin
        }

    def cleanup(self):
        GPIO.cleanup()

try:
    gpio_controller = GPIOController(COIN_INPUT_PIN, RELAY_OUTPUT_PIN)
except Exception as e:
    logger.warning(f"GPIO not available (running on non-RPi): {e}")
    gpio_controller = None

# ============================================================================
# LICENSE MANAGER
# ============================================================================

class LicenseManager:
    def __init__(self, license_path):
        self.license_path = license_path
        self.device_fingerprint = self.get_device_fingerprint()
        self.license_data = self.load_license()

    def get_device_fingerprint(self):
        """Generate device fingerprint from CPU serial + MAC address"""
        try:
            # Get CPU serial
            with open('/proc/cpuinfo', 'r') as f:
                for line in f:
                    if line.startswith('Serial'):
                        cpu_serial = line.split(':')[1].strip()
                        break
            
            # Get MAC address
            mac_address = self.get_mac_address()
            
            # Create fingerprint
            fingerprint_str = f"{cpu_serial}:{mac_address}"
            fingerprint = hashlib.sha256(fingerprint_str.encode()).hexdigest()
            
            logger.info(f"Device fingerprint: {fingerprint}")
            return fingerprint
        except Exception as e:
            logger.warning(f"Could not generate device fingerprint: {e}")
            return "trial-mode"

    def get_mac_address(self):
        """Get primary network interface MAC address"""
        try:
            mac = open('/sys/class/net/eth0/address').read().strip()
            return mac
        except:
            try:
                mac = open('/sys/class/net/wlan0/address').read().strip()
                return mac
            except:
                return "00:00:00:00:00:00"

    def load_license(self):
        """Load license from file"""
        if os.path.exists(self.license_path):
            try:
                with open(self.license_path, 'r') as f:
                    return json.load(f)
            except Exception as e:
                logger.error(f"Error loading license: {e}")
        return None

    def validate_license(self):
        """Validate license"""
        if not self.license_data:
            return False, "No license found"
        
        if self.license_data.get('fingerprint') != self.device_fingerprint:
            return False, "Device fingerprint mismatch (anti-tamper)"
        
        expiry = self.license_data.get('expiry')
        if expiry and datetime.fromisoformat(expiry) < datetime.now():
            return False, "License expired"
        
        return True, "License valid"

    def activate_license(self, activation_key):
        """Activate license online"""
        # In production, this would verify with licensing server
        # For now, we'll create a permanent offline license
        
        license_data = {
            'fingerprint': self.device_fingerprint,
            'activation_key': activation_key,
            'activated_at': datetime.now().isoformat(),
            'expiry': None,  # No expiry
            'version': '1.0',
            'max_clients': 999
        }
        
        try:
            os.makedirs(os.path.dirname(self.license_path), exist_ok=True)
            with open(self.license_path, 'w') as f:
                json.dump(license_data, f, indent=2)
            
            self.license_data = license_data
            logger.info("License activated successfully")
            return True, "License activated"
        except Exception as e:
            logger.error(f"License activation error: {e}")
            return False, f"Activation error: {e}"

    def get_status(self):
        """Get license status"""
        valid, message = self.validate_license()
        
        if self.license_data:
            return {
                'licensed': valid,
                'fingerprint': self.device_fingerprint,
                'activated_at': self.license_data.get('activated_at'),
                'expiry': self.license_data.get('expiry'),
                'max_clients': self.license_data.get('max_clients', 999)
            }
        else:
            return {
                'licensed': False,
                'mode': 'trial',
                'max_clients': TRIAL_MAX_CLIENTS,
                'max_minutes': TRIAL_MAX_MINUTES,
                'fingerprint': self.device_fingerprint
            }

license_manager = LicenseManager(LICENSE_PATH)

# ============================================================================
# AUTHENTICATION
# ============================================================================

ADMIN_USERNAME = 'admin'
ADMIN_PASSWORD = 'admin123'

def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user' not in session:
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated_function

# ============================================================================
# ROUTES - AUTHENTICATION
# ============================================================================

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        
        if username == ADMIN_USERNAME and password == ADMIN_PASSWORD:
            session['user'] = username
            logger.info(f"User {username} logged in")
            return redirect(url_for('dashboard'))
        else:
            return render_template('login.html', error='Invalid credentials')
    
    return render_template('login.html')

@app.route('/logout')
def logout():
    session.pop('user', None)
    return redirect(url_for('login'))

# ============================================================================
# ROUTES - API
# ============================================================================

@app.route('/api/register', methods=['POST'])
def api_register_client():
    """Register a new client"""
    data = request.json
    client_id = data.get('client_id')
    name = data.get('name', 'Unknown')
    ip_address = request.remote_addr
    mac_address = data.get('mac_address', '')
    
    # Check trial limits
    clients = db_manager.get_all_clients()
    active_clients = [c for c in clients if c['status'] == 'active']
    
    license_status = license_manager.get_status()
    max_clients = license_status.get('max_clients', TRIAL_MAX_CLIENTS)
    
    if len(active_clients) >= max_clients:
        return jsonify({'success': False, 'error': 'Maximum clients exceeded'}), 403
    
    success = db_manager.register_client(client_id, name, ip_address, mac_address)
    
    return jsonify({
        'success': success,
        'client_id': client_id,
        'server_time': datetime.now().isoformat()
    })

@app.route('/api/clients', methods=['GET'])
def api_get_clients():
    """Get all registered clients"""
    clients = db_manager.get_all_clients()
    return jsonify(clients)

@app.route('/api/client/<client_id>', methods=['GET'])
def api_get_client(client_id):
    """Get client details"""
    client = db_manager.get_client(client_id)
    if client:
        return jsonify(client)
    return jsonify({'error': 'Client not found'}), 404

@app.route('/api/client/<client_id>/add-time', methods=['POST'])
def api_add_time(client_id):
    """Add time to client"""
    data = request.json
    minutes = data.get('minutes', 1)
    
    db_manager.update_client_time(client_id, minutes)
    db_manager.add_transaction(client_id, 0, f'add-time-{minutes}min')
    
    return jsonify({'success': True, 'added_minutes': minutes})

@app.route('/api/gpio/status', methods=['GET'])
def api_gpio_status():
    """Get GPIO status"""
    if gpio_controller:
        return jsonify(gpio_controller.get_status())
    return jsonify({'error': 'GPIO not available'}), 503

@app.route('/api/gpio/relay', methods=['POST'])
def api_gpio_relay():
    """Control relay"""
    if not gpio_controller:
        return jsonify({'error': 'GPIO not available'}), 503
    
    data = request.json
    action = data.get('action')
    
    if action == 'on':
        gpio_controller.relay_on()
    elif action == 'off':
        gpio_controller.relay_off()
    
    return jsonify(gpio_controller.get_status())

@app.route('/api/license/status', methods=['GET'])
def api_license_status():
    """Get license status"""
    return jsonify(license_manager.get_status())

@app.route('/api/license/activate', methods=['POST'])
def api_license_activate():
    """Activate license"""
    data = request.json
    activation_key = data.get('activation_key', 'auto-activation')
    
    success, message = license_manager.activate_license(activation_key)
    
    return jsonify({
        'success': success,
        'message': message,
        'license_status': license_manager.get_status()
    })

@app.route('/api/server/info', methods=['GET'])
def api_server_info():
    """Get server info"""
    clients = db_manager.get_all_clients()
    active_clients = [c for c in clients if c['status'] == 'active']
    
    return jsonify({
        'server_name': HOSTNAME,
        'server_ip': socket.gethostbyname(socket.gethostname()),
        'total_clients': len(clients),
        'active_clients': len(active_clients),
        'uptime': os.popen('uptime -p').read().strip(),
        'license_status': license_manager.get_status()
    })

# ============================================================================
# ROUTES - WEB PAGES
# ============================================================================

@app.route('/')
def index():
    return redirect(url_for('login'))

@app.route('/dashboard')
@login_required
def dashboard():
    """Admin dashboard"""
    clients = db_manager.get_all_clients()
    license_status = license_manager.get_status()
    
    return render_template('dashboard.html',
                         clients=clients,
                         license_status=license_status,
                         gpio_available=gpio_controller is not None)

@app.route('/license')
@login_required
def license_page():
    """License manager page"""
    license_status = license_manager.get_status()
    device_fingerprint = license_manager.device_fingerprint
    
    return render_template('license.html',
                         license_status=license_status,
                         device_fingerprint=device_fingerprint)

@app.route('/logs')
@login_required
def logs_page():
    """System logs page"""
    try:
        with open(LOG_PATH, 'r') as f:
            logs = f.readlines()[-100:]  # Last 100 lines
    except:
        logs = ["No logs available"]
    
    return render_template('logs.html', logs=logs)

# ============================================================================
# MAIN
# ============================================================================

if __name__ == '__main__':
    logger.info("=" * 60)
    logger.info("🪙 PisoNet Server Starting...")
    logger.info("=" * 60)
    
    logger.info(f"Server: {HOSTNAME}")
    logger.info(f"Port: {SERVER_PORT}")
    logger.info(f"GPIO Coin Pin: {COIN_INPUT_PIN}")
    logger.info(f"GPIO Relay Pin: {RELAY_OUTPUT_PIN}")
    logger.info(f"License Status: {license_manager.get_status()}")
    
    try:
        app.run(host=SERVER_IP, port=SERVER_PORT, debug=False, threaded=True)
    except KeyboardInterrupt:
        logger.info("Shutting down...")
        if gpio_controller:
            gpio_controller.cleanup()
        sys.exit(0)
