# ⚙️ PisoNet Configuration Guide

## Server Configuration

### Main Server File: `/opt/pisonet/pisonet_server.py`

Located near the top of the file, around line 20-40:

```python
# ============================================================================
# CONFIGURATION
# ============================================================================

SERVER_IP = "0.0.0.0"              # Bind to all interfaces
SERVER_PORT = 5000                 # Main API port
HOSTNAME = "pisonet.local"         # mDNS hostname

# GPIO Configuration
COIN_INPUT_PIN = 3                 # Coin detector GPIO pin
RELAY_OUTPUT_PIN = 5               # Relay control GPIO pin

# Trial Mode (if no valid license)
TRIAL_MAX_CLIENTS = 2              # Max concurrent clients
TRIAL_MAX_MINUTES = 30             # Max session time

# Paths
DB_PATH = "/var/lib/pisonet/pisonet.db"
LICENSE_PATH = "/var/lib/pisonet/license.key"
LOG_PATH = "/var/log/pisonet/server.log"
```

### Changing Configuration

**Example 1: Change coin detection pin**

If you're using GPIO pin 17 instead of pin 3:

```python
COIN_INPUT_PIN = 17
```

Then restart:
```bash
sudo systemctl restart pisonet
```

**Example 2: Change server port**

If port 5000 is in use:

```python
SERVER_PORT = 5001
```

Update all clients to use new port in `client_config.ini`

**Example 3: Change trial limits**

For unlimited trial period:

```python
TRIAL_MAX_CLIENTS = 999
TRIAL_MAX_MINUTES = 999
```

**Example 4: Change database location**

Store database on external drive:

```python
DB_PATH = "/media/usb/pisonet.db"
LICENSE_PATH = "/media/usb/license.key"
LOG_PATH = "/media/usb/pisonet.log"
```

---

## Client Configuration

### Client Config File: `client_config.ini`

**Windows Location:**
```
C:\Users\YourName\AppData\Roaming\PisoNet\client_config.ini
```

**Linux Location:**
```
~/.config/PisoNet/client_config.ini
```

**Mac Location:**
```
~/Library/Application Support/PisoNet/client_config.ini
```

### Configuration Sections

#### [Server] - Server Connection

```ini
[Server]
server_ip = 192.168.1.100         # Server IP address
server_port = 5000                # Server port
server_hostname = pisonet.local    # Server hostname (mDNS)
```

**How it works:**
1. If `server_hostname` is set, tries to resolve it via mDNS
2. If that fails, uses `server_ip`
3. `server_port` used for both

**Example - Multiple servers:**
```ini
# Server 1 (Primary)
server_ip = 192.168.1.100
server_port = 5000

# Or Server 2 (Fallback)
server_ip = 192.168.1.101
server_port = 5000
```

#### [Client] - Client Settings

```ini
[Client]
client_name = Workstation-1        # Display name in dashboard
check_interval = 1                 # Sync interval (seconds)
```

**Options:**

| Setting | Range | Description |
|---------|-------|-------------|
| client_name | Any string | Appears in server dashboard |
| check_interval | 0.1-10 | How often to sync with server |

**Examples:**

```ini
# Fast sync (more network traffic)
check_interval = 0.5

# Slow sync (less responsive)
check_interval = 5

# Gaming station
client_name = Gaming-Station-1

# Classroom
client_name = Class-A-Computer-5
```

#### [UI] - User Interface

```ini
[UI]
timer_x = 10                       # X position (pixels from left)
timer_y = 10                       # Y position (pixels from top)
timer_width = 300                  # Window width
timer_height = 150                 # Window height
transparency = 0.9                 # 0.0=invisible, 1.0=opaque
```

**Window Positioning:**

```
(0,0) - Top Left
+───────────────────────────────+
│ (10,10) Timer Window          │ 1080p screen
│ ┌──────────────────────────┐   │
│ │ 00:45:30                │   │
│ │ Workstation-1           │   │
│ │ [+1min] [+30min]        │   │
│ └──────────────────────────┘   │
│                                 │
│                  (1920, 1080)   │
+───────────────────────────────+
```

**Common Positions:**

```ini
# Top-left corner (default)
timer_x = 10
timer_y = 10

# Top-right corner (1920x1080 screen)
timer_x = 1620
timer_y = 10

# Bottom-left corner
timer_x = 10
timer_y = 930

# Bottom-right corner
timer_x = 1620
timer_y = 930

# Center
timer_x = 810
timer_y = 465
```

**Transparency:**

```ini
# Fully opaque (solid white background)
transparency = 1.0

# Default (90% opaque)
transparency = 0.9

# Mostly transparent (10% opaque - barely visible)
transparency = 0.1

# Completely transparent (invisible)
transparency = 0.0
```

**Window Size:**

```ini
# Compact (mini timer)
timer_width = 200
timer_height = 100

# Default
timer_width = 300
timer_height = 150

# Large (prominent)
timer_width = 400
timer_height = 200
```

---

## Full Configuration Examples

### Minimal Configuration

```ini
[Server]
server_ip = 192.168.1.100
server_port = 5000

[Client]
client_name = Workstation

[UI]
timer_x = 10
timer_y = 10
timer_width = 300
timer_height = 150
transparency = 0.9
```

### Gaming Cafe Setup

```ini
[Server]
server_ip = 192.168.1.50
server_port = 5000
server_hostname = pisonet.local

[Client]
client_name = Gaming-Booth-1
check_interval = 0.5

[UI]
timer_x = 1620
timer_y = 10
timer_width = 300
timer_height = 150
transparency = 0.95
```

### Classroom Setup

```ini
[Server]
server_ip = 192.168.1.100
server_port = 5000

[Client]
client_name = Class-A-01
check_interval = 2

[UI]
timer_x = 10
timer_y = 10
timer_width = 250
timer_height = 120
transparency = 1.0
```

### Large Network Setup (Multiple Subnets)

```ini
[Server]
server_ip = 10.50.1.100
server_port = 5000
server_hostname = pisonet.example.com

[Client]
client_name = Building-2-Station-5
check_interval = 1

[UI]
timer_x = 10
timer_y = 10
timer_width = 300
timer_height = 150
transparency = 0.9
```

---

## Advanced Configuration

### Database Customization

**Change check interval (server-side):**

In `pisonet_server.py`, around line 400:

```python
# Sync interval for clients
CLIENT_SYNC_INTERVAL = 1  # seconds

# Coin detection debounce
COIN_DEBOUNCE = 0.5  # seconds
```

### GPIO Customization

**Using different GPIO pins:**

```python
# For different relay pin (e.g., GPIO 27)
RELAY_OUTPUT_PIN = 27

# For different coin pin (e.g., GPIO 17)
COIN_INPUT_PIN = 17
```

**Check available pins on your board:**

```bash
gpio readall
```

### Network Customization

**Run on specific interface:**

```python
SERVER_IP = "192.168.1.100"  # Instead of "0.0.0.0"
```

**Use custom hostname:**

```python
HOSTNAME = "cybercafe1.local"
```

Then update `/etc/hostname`:
```bash
sudo nano /etc/hostname
# Change to: cybercafe1
```

### Database Customization

**SQLite pragma settings for performance:**

In `pisonet_server.py`, in `DatabaseManager.init_db()`:

```python
# Fast mode (less safe, but faster)
cursor.execute('PRAGMA synchronous = OFF')
cursor.execute('PRAGMA journal_mode = MEMORY')

# Or safe mode (slower, but safer)
cursor.execute('PRAGMA synchronous = FULL')
```

---

## Security Configuration

### Admin Password

**Change default password:**

In `pisonet_server.py`, around line 300:

```python
ADMIN_USERNAME = 'admin'
ADMIN_PASSWORD = 'your-secure-password-here'
```

Restart service:
```bash
sudo systemctl restart pisonet
```

### SSL/TLS (HTTPS)

For production, use reverse proxy:

**Using nginx:**

```bash
sudo apt-get install nginx

# Create self-signed certificate
sudo openssl req -x509 -nodes -days 365 -newkey rsa:2048 \
  -keyout /etc/ssl/private/pisonet.key \
  -out /etc/ssl/certs/pisonet.crt
```

**nginx config (`/etc/nginx/sites-available/pisonet`):**

```nginx
server {
    listen 443 ssl;
    server_name pisonet.local;

    ssl_certificate /etc/ssl/certs/pisonet.crt;
    ssl_certificate_key /etc/ssl/private/pisonet.key;

    location / {
        proxy_pass http://localhost:5000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
    }
}

server {
    listen 80;
    server_name pisonet.local;
    return 301 https://$server_name$request_uri;
}
```

Enable and restart:
```bash
sudo ln -s /etc/nginx/sites-available/pisonet /etc/nginx/sites-enabled/
sudo systemctl restart nginx
```

### Firewall Rules

**Allow only specific clients:**

```bash
# UFW firewall
sudo ufw default deny incoming
sudo ufw default allow outgoing
sudo ufw allow from 192.168.1.0/24 to any port 5000
```

---

## Backup & Recovery

### Backup Configuration

```bash
# Backup server config
sudo cp -r /var/lib/pisonet /var/lib/pisonet.backup

# Backup entire server
sudo tar -czf pisonet-backup.tar.gz /opt/pisonet /var/lib/pisonet

# Transfer to Windows
scp pi@192.168.1.100:~/pisonet-backup.tar.gz C:\Backups\
```

### Restore Configuration

```bash
# Restore from backup
sudo tar -xzf pisonet-backup.tar.gz -C /

# Or restore specific files
sudo cp /var/lib/pisonet.backup/pisonet.db /var/lib/pisonet/
```

---

## Environment Variables

### Set via systemd

Edit `/etc/systemd/system/pisonet.service`:

```ini
[Service]
Environment="PYTHONUNBUFFERED=1"
Environment="FLASK_ENV=production"
```

Restart:
```bash
sudo systemctl daemon-reload
sudo systemctl restart pisonet
```

---

## Troubleshooting Configuration Issues

### Client can't find server

**Check configuration:**
```bash
# Verify config file exists
type %APPDATA%\PisoNet\client_config.ini

# Test connection manually
ping 192.168.1.100
curl http://192.168.1.100:5000/login
```

### Port already in use

**Find what's using the port:**
```bash
sudo lsof -i :5000
```

**Change port in:**
1. `pisonet_server.py` → `SERVER_PORT = 5001`
2. All `client_config.ini` → `server_port = 5001`

### GPIO not working after config change

**Verify pin numbers are correct:**
```bash
gpio readall

# Make sure pin exists and is not already in use
```

**Test manually:**
```bash
gpio mode 3 in
gpio read 3

gpio mode 5 out
gpio write 5 1
```

---

**Last Updated:** 2024-01-15  
**PisoNet Version:** 1.0.0
