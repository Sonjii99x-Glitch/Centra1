# 🔌 PisoNet REST API Documentation

## Base URL
```
http://pisonet.local:5000
```

## Authentication
All API endpoints except `/login` require a valid session. Use the web dashboard to authenticate first.

---

## 📊 API Endpoints

### Authentication

#### POST `/login`
Login to the admin dashboard
```bash
curl -X POST http://pisonet.local:5000/login \
  -d "username=admin&password=admin123"
```

**Response:**
- Redirects to dashboard on success
- Redirects to login on failure

#### GET `/logout`
Logout from session
```bash
curl http://pisonet.local:5000/logout
```

---

### Clients

#### POST `/api/register`
Register a new client
```bash
curl -X POST http://pisonet.local:5000/api/register \
  -H "Content-Type: application/json" \
  -d '{
    "client_id": "client-uuid-here",
    "name": "Workstation-1",
    "mac_address": "00:11:22:33:44:55"
  }'
```

**Request:**
- `client_id` (string): Unique client ID (UUID)
- `name` (string): Display name for client
- `mac_address` (string): MAC address

**Response:**
```json
{
  "success": true,
  "client_id": "client-uuid-here",
  "server_time": "2024-01-15T10:30:00.000000"
}
```

**Errors:**
- 403: Maximum clients exceeded (trial mode)

---

#### GET `/api/clients`
Get all registered clients
```bash
curl http://pisonet.local:5000/api/clients
```

**Response:**
```json
[
  {
    "id": 1,
    "client_id": "uuid-123",
    "name": "Workstation-1",
    "ip_address": "192.168.1.50",
    "mac_address": "00:11:22:33:44:55",
    "total_time": 3600,
    "remaining_time": 1800,
    "status": "active",
    "last_seen": "2024-01-15T10:30:00",
    "created_at": "2024-01-15T09:00:00"
  }
]
```

---

#### GET `/api/client/<client_id>`
Get specific client details
```bash
curl http://pisonet.local:5000/api/client/uuid-123
```

**Response:**
```json
{
  "id": 1,
  "client_id": "uuid-123",
  "name": "Workstation-1",
  "ip_address": "192.168.1.50",
  "total_time": 3600,
  "remaining_time": 1800,
  "status": "active",
  "last_seen": "2024-01-15T10:30:00"
}
```

---

#### POST `/api/client/<client_id>/add-time`
Add time to a client
```bash
curl -X POST http://pisonet.local:5000/api/client/uuid-123/add-time \
  -H "Content-Type: application/json" \
  -d '{"minutes": 30}'
```

**Request:**
- `minutes` (integer): Minutes to add

**Response:**
```json
{
  "success": true,
  "added_minutes": 30
}
```

---

### GPIO Control

#### GET `/api/gpio/status`
Get GPIO status
```bash
curl http://pisonet.local:5000/api/gpio/status
```

**Response:**
```json
{
  "coin_detected": false,
  "relay_active": false,
  "coin_pin": 3,
  "relay_pin": 5
}
```

---

#### POST `/api/gpio/relay`
Control relay output
```bash
curl -X POST http://pisonet.local:5000/api/gpio/relay \
  -H "Content-Type: application/json" \
  -d '{"action": "on"}'
```

**Request:**
- `action` (string): "on" or "off"

**Response:**
```json
{
  "coin_detected": false,
  "relay_active": true,
  "coin_pin": 3,
  "relay_pin": 5
}
```

---

### License

#### GET `/api/license/status`
Get license status
```bash
curl http://pisonet.local:5000/api/license/status
```

**Response (Licensed):**
```json
{
  "licensed": true,
  "fingerprint": "sha256hash...",
  "activated_at": "2024-01-15T10:00:00",
  "expiry": null,
  "max_clients": 999
}
```

**Response (Trial):**
```json
{
  "licensed": false,
  "mode": "trial",
  "max_clients": 2,
  "max_minutes": 30,
  "fingerprint": "sha256hash..."
}
```

---

#### POST `/api/license/activate`
Activate license online
```bash
curl -X POST http://pisonet.local:5000/api/license/activate \
  -H "Content-Type: application/json" \
  -d '{"activation_key": "auto-activation"}'
```

**Response:**
```json
{
  "success": true,
  "message": "License activated",
  "license_status": {
    "licensed": true,
    "fingerprint": "...",
    "activated_at": "2024-01-15T10:30:00",
    "max_clients": 999
  }
}
```

---

### Server

#### GET `/api/server/info`
Get server information
```bash
curl http://pisonet.local:5000/api/server/info
```

**Response:**
```json
{
  "server_name": "pisonet.local",
  "server_ip": "192.168.1.100",
  "total_clients": 5,
  "active_clients": 2,
  "uptime": "2 days, 3 hours",
  "license_status": {
    "licensed": true,
    "max_clients": 999
  }
}
```

---

## 📋 Database Schema

### Clients Table
```sql
CREATE TABLE clients (
  id INTEGER PRIMARY KEY,
  client_id TEXT UNIQUE NOT NULL,
  name TEXT NOT NULL,
  ip_address TEXT,
  mac_address TEXT,
  total_time INTEGER DEFAULT 0,
  remaining_time INTEGER DEFAULT 0,
  status TEXT DEFAULT 'idle',
  last_seen TIMESTAMP,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

### Sessions Table
```sql
CREATE TABLE sessions (
  id INTEGER PRIMARY KEY,
  client_id TEXT NOT NULL,
  start_time TIMESTAMP,
  end_time TIMESTAMP,
  duration INTEGER,
  cost REAL DEFAULT 0,
  FOREIGN KEY (client_id) REFERENCES clients(client_id)
);
```

### Transactions Table
```sql
CREATE TABLE transactions (
  id INTEGER PRIMARY KEY,
  client_id TEXT NOT NULL,
  amount REAL,
  type TEXT,
  timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (client_id) REFERENCES clients(client_id)
);
```

---

## 🔒 Device Fingerprinting

Device fingerprint is generated from:
1. CPU Serial (from `/proc/cpuinfo`)
2. MAC Address (from `/sys/class/net/eth0/address` or `wlan0`)
3. SHA256 hash of combined string

**Example:**
```
CPU Serial: 1234567890abcdef
MAC Address: b8:27:eb:ab:cd:ef
Combined: 1234567890abcdef:b8:27:eb:ab:cd:ef
Fingerprint: SHA256(combined)
```

---

## 📱 Client Registration Flow

1. **Client starts:**
   ```javascript
   clientId = generateUUID();
   macAddress = getSystemMAC();
   POST /api/register
   ```

2. **Server registers client:**
   - Stores client_id, name, IP, MAC
   - Returns confirmation
   - Updates last_seen timestamp

3. **Client syncs periodically:**
   ```javascript
   GET /api/client/{clientId}
   // Updates UI with remaining_time, status
   ```

4. **Server responds with:**
   - remaining_time (seconds)
   - total_time (seconds)
   - status (active/idle/blocked)

---

## ⏱️ Time Management

### Time Units
- All time values in **seconds**
- Display as HH:MM:SS

### Calculation
```python
# On client
remaining_minutes = remaining_time // 60
remaining_seconds = remaining_time % 60

# Server
remaining_time = minutes * 60 + seconds
```

### Trial Limits
```python
# Trial mode
max_clients = 2
max_minutes_per_session = 30
auto_shutdown = True if time_elapsed > 30 * 60
```

---

## 🔑 License Activation Process

1. **Device sends fingerprint to server:**
   ```json
   {
     "fingerprint": "sha256hash...",
     "device_info": {
       "cpu": "ARM...",
       "mac": "b8:27:eb:...",
       "hostname": "pisonet.local"
     }
   }
   ```

2. **Server validates and creates license:**
   ```json
   {
     "fingerprint": "sha256hash...",
     "license_key": "PIZ0NE7-...",
     "activated_at": "2024-01-15T10:00:00",
     "expiry": null
   }
   ```

3. **License stored locally:**
   - `/var/lib/pisonet/license.key` (Linux)
   - `C:\ProgramData\PisoNet\license.key` (Windows)

4. **Anti-tamper validation:**
   - On startup, verify fingerprint matches
   - If mismatch, prompt for reactivation
   - Prevents license sharing across devices

---

## 💾 Response Codes

| Code | Meaning |
|------|---------|
| 200 | OK - Request successful |
| 403 | Forbidden - License/Trial limit exceeded |
| 404 | Not Found - Client/Resource not found |
| 500 | Server Error - Internal error |
| 503 | Service Unavailable - GPIO not available |

---

## 🧪 Testing with cURL

**Register a client:**
```bash
curl -X POST http://pisonet.local:5000/api/register \
  -H "Content-Type: application/json" \
  -d '{
    "client_id": "test-client-1",
    "name": "Test Workstation",
    "mac_address": "00:11:22:33:44:55"
  }'
```

**Get all clients:**
```bash
curl http://pisonet.local:5000/api/clients
```

**Add time:**
```bash
curl -X POST http://pisonet.local:5000/api/client/test-client-1/add-time \
  -H "Content-Type: application/json" \
  -d '{"minutes": 60}'
```

**Control relay:**
```bash
curl -X POST http://pisonet.local:5000/api/gpio/relay \
  -H "Content-Type: application/json" \
  -d '{"action": "on"}'
```

**Activate license:**
```bash
curl -X POST http://pisonet.local:5000/api/license/activate \
  -H "Content-Type: application/json" \
  -d '{"activation_key": "auto-activation"}'
```

---

**API Version:** 1.0.0  
**Last Updated:** 2024-01-15
