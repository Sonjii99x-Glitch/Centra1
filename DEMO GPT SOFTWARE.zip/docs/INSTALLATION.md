# 📦 PisoNet Complete Installation Guide

## Table of Contents
1. [Orange Pi Server Setup](#orange-pi-server-setup)
2. [Windows Client Installation](#windows-client-installation)
3. [License Activation](#license-activation)
4. [Network Configuration](#network-configuration)
5. [GPIO Hardware Setup](#gpio-hardware-setup)
6. [Troubleshooting](#troubleshooting)

---

## Orange Pi Server Setup

### Requirements
- Orange Pi One (1GB RAM) or Raspberry Pi 3+
- MicroSD Card (8GB+)
- Armbian or Raspberry Pi OS installed
- WiFi or Ethernet connection
- GPIO coin detector and relay

### Step 1: SSH into Orange Pi

**Find your Orange Pi IP:**
```bash
# On Windows (Command Prompt)
ping orangepi.local

# On Mac/Linux (Terminal)
ping orangepi.local
```

**Or use network scanner:**
- Install "Advanced IP Scanner" on Windows
- Look for "orangepi" in your network

**Connect via SSH:**
```bash
ssh root@192.168.x.x
# Default password: 1234 (Orange Pi) or raspberry (Raspberry Pi)
```

### Step 2: Run Installation Script

**Option A: Using curl (Recommended)**
```bash
curl -O https://raw.githubusercontent.com/yourusername/pisonet/main/server/install.sh
chmod +x install.sh
sudo ./install.sh
```

**Option B: Manual Installation**
```bash
# Update system
sudo apt-get update
sudo apt-get upgrade -y

# Install dependencies
sudo apt-get install -y python3 python3-pip python3-dev git

# Install Python packages
sudo pip3 install Flask==3.0.0 Flask-CORS==4.0.0 RPi.GPIO==0.7.0

# Create directories
sudo mkdir -p /opt/pisonet /var/lib/pisonet /var/log/pisonet

# Copy server files
sudo cp pisonet_server.py /opt/pisonet/
sudo cp -r templates/ /opt/pisonet/

# Setup service
sudo cp pisonet.service /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl enable pisonet
sudo systemctl start pisonet
```

### Step 3: Verify Installation

```bash
# Check service status
sudo systemctl status pisonet

# View logs
sudo journalctl -u pisonet -f

# Test server
curl http://localhost:5000/login
```

### Step 4: Access Admin Dashboard

Open in browser:
```
http://pisonet.local:5000
```

**Default credentials:**
- Username: `admin`
- Password: `admin123`

⚠️ **CHANGE PASSWORD IMMEDIATELY AFTER FIRST LOGIN!**

---

## Windows Client Installation

### Requirements
- Windows 7 or later
- Python 3.8+ installed
- Network connection to Orange Pi

### Step 1: Install Python

1. Download from: https://www.python.org/downloads/
2. Run installer
3. **IMPORTANT**: Check "Add Python to PATH"
4. Verify installation:
   ```bash
   python --version
   ```

### Step 2: Run Client Installer

**Option A: Using Batch File (Easiest)**
1. Download `oneclick_client.bat`
2. Right-click → Run as Administrator
3. Follow prompts

**Option B: Using Python Installer**
1. Download `oneclick_installer.py`
2. Double-click to run
3. Select "1) Install Windows Client"
4. Follow prompts

**Option C: Manual Installation**
```bash
# Create directory
mkdir %APPDATA%\PisoNet

# Install dependencies
pip install PyQt5==5.15.9 requests==2.31.0

# Copy client script
copy pisonet_client.py %APPDATA%\PisoNet\

# Create config
# See Configuration section below
```

### Step 3: Configure Client

Edit: `C:\Users\YourUsername\AppData\Roaming\PisoNet\client_config.ini`

```ini
[Server]
server_ip = 192.168.1.100
server_port = 5000
server_hostname = pisonet.local

[Client]
client_name = Workstation-1
check_interval = 1

[UI]
timer_x = 10
timer_y = 10
timer_width = 300
timer_height = 150
transparency = 0.9
```

### Step 4: Start Client

**First Time:**
```bash
python %APPDATA%\PisoNet\pisonet_client.py
```

**Subsequent Times:**
- Double-click PisoNet shortcut on desktop

### Step 5: Verify Connection

You should see:
- Timer window appears in top-left corner
- Status shows "🟢 Active" or "⚪ Idle"
- Client appears in server dashboard

---

## License Activation

### Trial Mode

Without license:
- Max 2 concurrent clients
- 30 minutes per session
- All features available
- No internet required

### Online Activation

**Step 1: Open Admin Dashboard**
```
http://pisonet.local:5000
```

**Step 2: Go to License Tab**
Click "License" in top menu

**Step 3: Click "Activate Online"**
- Requires internet connection for this one time
- Your device fingerprint is sent to activation server
- License is generated and stored locally

**Step 4: Offline Operation**
- After activation, NO internet needed
- Works permanently offline
- Anti-tamper protection active

### License File Location

**Orange Pi:**
```
/var/lib/pisonet/license.key
```

**Windows:**
```
C:\ProgramData\PisoNet\license.key
```

---

## Network Configuration

### Finding Your Server

**Using mDNS (Recommended):**
```bash
# Windows, Mac, or Linux
ping pisonet.local
```

**Using IP Scanner:**
1. Download Advanced IP Scanner (Windows)
2. Scan your local network
3. Look for "pisonet"

### Port Forwarding (Advanced)

If clients are on different network:

1. On your router, forward:
   - Port 5000 → Orange Pi (192.168.x.x:5000)

2. Configure firewall to allow port 5000

3. Access from remote:
   ```
   http://your-public-ip:5000
   ```

### Firewall Rules

**Linux (UFW):**
```bash
sudo ufw allow 5000/tcp
sudo ufw allow 5001/tcp
```

**Windows Firewall:**
1. Settings → Windows Firewall → Advanced Settings
2. Inbound Rules → New Rule
3. Allow port 5000 and 5001

---

## GPIO Hardware Setup

### Wiring Diagram

```
COIN DETECTOR (Coin Input Pin 3)
┌─────────────────────┐
│ Coin Detector       │
│ (Normally Open)     │
└─────┬───────────────┘
      │
      ├── GND (Black)
      └── GPIO 3 (Green)

RELAY (Output Pin 5)
┌─────────────────────┐
│ Relay 5V Module     │
│                     │
├── GND ──────────────── GND (Black)
├── VCC ──────────────── 5V (Red)
├── IN ───────────────── GPIO 5 (White)
└─ Common/NO ──────────── Your Circuit
```

### Pin Reference (Orange Pi One)

```
GPIO 3 = Pin 3 (PCM_DIN)  - Coin Input
GPIO 5 = Pin 5 (CLKOUT)   - Relay Output

Pinout (looking at board):
Pin 1  - 3.3V
Pin 2  - 5V
Pin 3  - GPIO3 (I2C SDA)    ← Coin
Pin 4  - 5V
Pin 5  - GPIO5 (I2C SCL)    ← Relay
Pin 6  - GND
...
```

### Test GPIO

```bash
# Check GPIO
gpio readall

# Test coin input (Pin 3)
gpio mode 3 in
gpio read 3

# Test relay output (Pin 5)
gpio mode 5 out
gpio write 5 1   # ON
gpio write 5 0   # OFF
```

### Hardware Troubleshooting

**No coin detection:**
1. Check wiring (Pin 3 and GND)
2. Test sensor independently
3. Check GPIO pin with: `gpio read 3`
4. View logs: `sudo journalctl -u pisonet -f | grep -i coin`

**Relay not working:**
1. Check power supply (5V)
2. Test relay module independently
3. Check wiring (Pin 5, VCC, GND)
4. Test: `gpio write 5 1` (should activate)
5. Check relay feedback in logs

---

## Troubleshooting

### Server Won't Start

**Check service status:**
```bash
sudo systemctl status pisonet
```

**View detailed logs:**
```bash
sudo journalctl -u pisonet -n 100
```

**Common issues:**
```bash
# Port already in use
sudo lsof -i :5000

# Kill process on port 5000
sudo kill -9 $(lsof -t -i:5000)

# Restart service
sudo systemctl restart pisonet
```

### Client Can't Find Server

**Test network connection:**
```bash
# Can you ping the server?
ping pisonet.local

# Can you reach the server port?
telnet pisonet.local 5000
```

**Check client config:**
```bash
# Windows
type %APPDATA%\PisoNet\client_config.ini

# Linux/Mac
cat ~/.config/PisoNet/client_config.ini
```

**Fix:**
1. Edit client_config.ini
2. Set correct server_ip
3. Set correct server_port (default 5000)
4. Restart client

### License Activation Fails

**Check internet connection:**
```bash
ping 8.8.8.8
```

**Check firewall:**
- Allow outbound HTTPS (port 443)
- Check Orange Pi firewall

**Manual activation:**
1. Note your fingerprint from License page
2. Contact support with fingerprint
3. Receive license key file
4. Place in `/var/lib/pisonet/license.key`

### GPIO Issues

**GPIO not found:**
- Install GPIO library: `sudo pip3 install RPi.GPIO`
- Check board is Raspberry Pi or Orange Pi
- Verify GPIO pins are correct

**Permission denied:**
```bash
# Run as root
sudo systemctl restart pisonet

# Or add user to gpio group
sudo usermod -aG gpio $USER
```

---

## Performance Optimization

### For Slow Networks

**Increase check interval (client):**
Edit `client_config.ini`:
```ini
[Client]
check_interval = 5
```

### For Unreliable Connections

**Enable retry logic:**
Edit `pisonet_client.py`, increase timeout:
```python
timeout = 10  # seconds
```

### Multiple Clients on Slow Server

**Reduce refresh rate (dashboard):**
Edit `templates/dashboard.html`:
```javascript
setInterval(updateDashboard, 5000);  // 5 seconds instead of 2
```

---

## System Requirements

### Minimum (Trial Mode)
- Orange Pi One: 1 GB RAM
- 2 concurrent clients
- 30 min per session

### Recommended (Licensed)
- Orange Pi Zero or better: 512 MB+ RAM
- Unlimited clients
- Unlimited sessions

### Network
- DHCP or Static IP
- 192.168.x.x or 10.x.x.x network
- 100 Mbps minimum

---

## Security Best Practices

1. **Change default password immediately**
   - Dashboard → Settings → Change Password

2. **Use HTTPS in production**
   - Use reverse proxy (nginx, Apache)
   - Install SSL certificate

3. **Secure SSH access**
   - Change default Orange Pi password
   - Disable root login
   - Use SSH keys instead of password

4. **Firewall**
   - Restrict port 5000 to local network only
   - Block WAN access unless needed

5. **Backups**
   - Backup `/var/lib/pisonet/` regularly
   - Backup license key file
   - Backup database `/var/lib/pisonet/pisonet.db`

---

## Getting Help

1. **Check logs:**
   ```bash
   sudo journalctl -u pisonet -f
   ```

2. **Server diagnostics:**
   - Visit Dashboard → Logs
   - Download and review logs

3. **Test connectivity:**
   ```bash
   # From client machine
   ping pisonet.local
   curl http://pisonet.local:5000/api/server/info
   ```

4. **Contact support:**
   - Include server logs
   - Include client logs
   - Describe what you did
   - Describe what happened

---

**Last Updated:** 2024
**PisoNet Version:** 1.0.0
