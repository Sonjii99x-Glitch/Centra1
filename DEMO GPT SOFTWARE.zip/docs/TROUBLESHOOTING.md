# 🔧 PisoNet Troubleshooting Guide

## Quick Fixes

### "Server not found" Error

**Problem:** Client can't connect to server

**Quick Fix:**
```bash
# On your server (Orange Pi)
hostname -I

# Use the IP address shown, edit client_config.ini:
server_ip = 192.168.x.x
```

**If that doesn't work:**
```bash
# From Windows Command Prompt
ping pisonet.local

# If it works, use pisonet.local in config
server_hostname = pisonet.local
```

---

### Client Timer Shows 00:00:00

**Problem:** Timer is not updating

**Cause:** Server connection lost

**Fix:**
1. Check server is running: `sudo systemctl status pisonet`
2. Check firewall allows port 5000
3. Restart client: Close and reopen
4. Check logs: `C:\Users\You\AppData\Roaming\PisoNet\client.log`

---

### License Activation Fails

**Problem:** "Activation error" when clicking Activate

**Check:**
1. Internet connection working? `ping 8.8.8.8`
2. Firewall blocking? Allow outbound HTTPS
3. Server has internet access? SSH and test

**Manual Fix:**
```bash
# On Orange Pi, test connectivity
curl -I https://google.com

# If no internet, activation will fail
# Use manual offline activation instead
```

---

### Coin Detector Not Working

**Problem:** Coins inserted but not detected

**Check Wiring:**
```bash
# SSH to Orange Pi
gpio readall

# Look for GPIO 3, test it:
gpio mode 3 in
gpio read 3

# Insert coin, should show 1, then 0
```

**If GPIO always shows 0:**
- Check coin detector wiring
- Test coin detector independently
- Check pin 3 has proper connection

**If GPIO works but server doesn't detect:**
```bash
# View server logs
sudo journalctl -u pisonet -f | grep -i coin

# If no logs appear, GPIO listening may be broken
# Restart service
sudo systemctl restart pisonet
```

---

### Relay Won't Activate

**Problem:** Relay not clicking even though dashboard shows "On"

**Check Power:**
```bash
# Verify 5V is available
gpio readall

# Should see voltage on pin 5
```

**Check Wiring:**
- 5V power to relay VCC (Red)
- GND to relay GND (Black)
- GPIO 5 to relay IN (White)
- Test each wire with multimeter

**Test Relay:**
```bash
# Test from command line
gpio mode 5 out
gpio write 5 1  # Should click
gpio write 5 0  # Should click back

# If relay doesn't click, it's likely broken
```

---

## Detailed Troubleshooting

### Server Issues

#### Server won't start

**Check systemd:**
```bash
sudo systemctl status pisonet
```

**If it says "failed":**
```bash
# View detailed error
sudo journalctl -u pisonet -n 20

# Common errors and fixes:
```

| Error | Fix |
|-------|-----|
| "Address already in use" | Port 5000 occupied: `sudo lsof -i :5000` |
| "Permission denied" | Run as root: `sudo systemctl start pisonet` |
| "Module not found" | Install packages: `sudo pip3 install Flask Flask-CORS RPi.GPIO` |

**Manual start for debugging:**
```bash
cd /opt/pisonet
sudo python3 pisonet_server.py

# This will show errors directly instead of in systemd
```

#### Port already in use

```bash
# Find what's using port 5000
sudo lsof -i :5000

# Kill the process
sudo kill -9 <PID>

# Or change port in pisonet_server.py:
# SERVER_PORT = 5001
```

#### Database locked

```bash
# Database may be corrupted
sudo rm /var/lib/pisonet/pisonet.db

# Service will recreate it on restart
sudo systemctl restart pisonet
```

#### High CPU/Memory usage

```bash
# Check processes
top

# If pisonet_server.py using 100% CPU:
# Kill and restart
sudo systemctl restart pisonet

# Check logs for infinite loops
sudo journalctl -u pisonet -n 100
```

---

### Network Issues

#### mDNS (pisonet.local) not working

**On Orange Pi:**
```bash
# Check mDNS service
sudo systemctl status avahi-daemon

# If not running:
sudo systemctl start avahi-daemon
sudo systemctl enable avahi-daemon

# Test it
hostname -I
ping pisonet.local
```

**On Windows Client:**
```bash
# Install Bonjour Print Services
# https://support.apple.com/kb/DL999

# Or use IP address directly instead of pisonet.local
server_ip = 192.168.1.100
```

#### Clients on different subnet

**Problem:** Client on 192.168.2.0 can't reach server on 192.168.1.0

**Solution:**
1. Configure port forwarding on router
2. Use DHCP reservation
3. Use IP address instead of hostname

---

### Client Issues

#### Client crashes on start

**Check Python version:**
```bash
python --version
# Must be 3.8 or higher
```

**Check dependencies:**
```bash
pip show PyQt5
pip show requests
# Both required
```

**Reinstall:**
```bash
pip install --force-reinstall PyQt5==5.15.9 requests==2.31.0
```

**Check logs:**
```bash
# Windows
type %APPDATA%\PisoNet\client.log
```

#### Timer window not appearing

**Check if running:**
```bash
# Windows Task Manager
# Look for Python.exe in Processes
```

**Start manually:**
```bash
# Windows Command Prompt
python %APPDATA%\PisoNet\pisonet_client.py

# If error shown, fix it
```

**Wrong config:**
```bash
# Check config file exists
type %APPDATA%\PisoNet\client_config.ini

# If missing or empty:
# Create it with correct values
```

#### Client won't add time

**Check connection:**
```bash
# From client machine
ping pisonet.local

# If fails, network issue
# If succeeds, server might be rejecting

# Check server logs for errors
sudo journalctl -u pisonet -f
# Then try adding time in client
# Watch for error messages
```

#### Client shows "Connecting..." forever

**Network issue:**
1. Check firewall allows port 5000
2. Try with IP address instead of hostname
3. Restart router
4. Check server is actually running

**Firewall fix (Windows):**
1. Settings → Windows Defender Firewall
2. Allow an app through firewall
3. Find Python, check both Private and Public
4. Click OK

---

### GPIO Issues

#### ImportError: No module named 'RPi.GPIO'

**On Orange Pi:**
```bash
sudo pip3 install RPi.GPIO

# If that fails:
sudo apt-get install python3-rpi.gpio
```

**On non-Raspberry Pi:**
This error is expected. Server won't have GPIO functionality.

#### GPIO: permission denied

```bash
# Add current user to gpio group
sudo usermod -aG gpio $USER

# Then logout and login again
# Or run as root:
sudo systemctl start pisonet
```

#### "No module named 'RPi'" when not on Raspberry Pi

**This is OK.** The server includes a try-except to handle this.
GPIO simply won't work, but everything else will.

---

### License Issues

#### License activation times out

**Check internet:**
```bash
# From Orange Pi
ping 8.8.8.8

# Must be able to reach internet
```

**Check firewall:**
```bash
# HTTPS (port 443) must be open
sudo ufw status
# If blocked:
sudo ufw allow 443/tcp
```

**Try manual activation:**
```bash
# Contact support with this info:
sudo python3 << 'EOF'
import hashlib
with open('/proc/cpuinfo') as f:
    for line in f:
        if 'Serial' in line:
            print(line.strip())
            
with open('/sys/class/net/eth0/address') as f:
    print(f.read().strip())
EOF
```

#### "Invalid fingerprint" error

**Problem:** License file doesn't match device

**Cause:** 
- Hardware changed (motherboard, CPU replaced)
- License file from different device
- License file corrupted

**Fix:**
```bash
# Delete old license
sudo rm /var/lib/pisonet/license.key

# Reactivate
# Go to http://pisonet.local:5000/license
# Click "Activate Online" again
```

---

### Dashboard Issues

#### Dashboard won't load

**Check server running:**
```bash
sudo systemctl status pisonet
```

**Check port:**
```bash
sudo lsof -i :5000
# Should show: python3 ... pisonet_server.py
```

**Try accessing directly:**
```bash
curl http://localhost:5000/login
# From Orange Pi should work

curl http://192.168.1.100:5000/login
# From other machine
```

#### Dashboard is slow

**Reduce refresh rate:**
Edit `/opt/pisonet/templates/dashboard.html`:
```javascript
// Change from:
setInterval(updateDashboard, 2000);

// To:
setInterval(updateDashboard, 5000);  // 5 seconds
```

**Reduce log lines:**
Edit `/opt/pisonet/pisonet_server.py`:
```python
# Change from:
logs = f.readlines()[-100:]

# To:
logs = f.readlines()[-50:]  # Last 50 lines
```

#### Can't login

**Check credentials:**
- Default username: `admin`
- Default password: `admin123`

**Reset password:**
```bash
# SSH to Orange Pi
# Edit pisonet_server.py:
ADMIN_PASSWORD = 'newpassword'

# Restart
sudo systemctl restart pisonet
```

---

### Performance Issues

#### High server load

**Check what's running:**
```bash
top
# Press Shift+M to sort by memory
# Press Shift+P to sort by CPU
```

**If pisonet_server.py high:**
- Too many clients connected
- Check for database lock
- Restart service: `sudo systemctl restart pisonet`

#### Client timer lags

**Increase check_interval:**
Edit `client_config.ini`:
```ini
[Client]
check_interval = 2
# Instead of 1 (seconds between sync)
```

**Reduce refresh rate:**
Edit `pisonet_client.py`:
```python
self.ui_timer.start(500)  # 500ms instead of 100ms
```

---

## Diagnostic Commands

### System Information

```bash
# Orange Pi specs
uname -a
free -h
df -h
```

### Network Diagnostics

```bash
# Check hostname
hostname
hostname -I

# Check mDNS
avahi-resolve -n pisonet.local

# Check firewall
sudo ufw status
```

### Server Diagnostics

```bash
# Check service
sudo systemctl status pisonet

# View recent logs
sudo journalctl -u pisonet -n 50

# Live monitoring
sudo journalctl -u pisonet -f

# Check database
sudo sqlite3 /var/lib/pisonet/pisonet.db ".tables"
sudo sqlite3 /var/lib/pisonet/pisonet.db "SELECT COUNT(*) FROM clients;"
```

### GPIO Diagnostics

```bash
# Show all GPIO pins
gpio readall

# Test input pin 3
gpio mode 3 in
gpio read 3

# Test output pin 5
gpio mode 5 out
gpio write 5 1
sleep 1
gpio write 5 0
```

### Client Diagnostics

```bash
# Check Python version
python --version

# Check installed packages
pip list | grep -E "PyQt5|requests"

# Test connection
curl http://pisonet.local:5000/api/server/info

# Check logs
type %APPDATA%\PisoNet\client.log
```

---

## Log Files

### Server Logs

**Location:**
```
/var/log/pisonet/server.log
/var/log/pisonet/
```

**View:**
```bash
# Real-time
sudo journalctl -u pisonet -f

# Last 100 lines
sudo journalctl -u pisonet -n 100

# Specific error
sudo journalctl -u pisonet -f | grep ERROR

# Specific client
sudo journalctl -u pisonet -f | grep client-id
```

### Client Logs

**Location:**
```
C:\Users\YourName\AppData\Roaming\PisoNet\client.log
```

**View:**
```
Notepad %APPDATA%\PisoNet\client.log
```

### Download Logs

**From Dashboard:**
1. Go to Logs page
2. Click "⬇️ Download"
3. Save and review

---

## Getting Help

### Collect Information

Before contacting support, gather:

```bash
# On Orange Pi
sudo journalctl -u pisonet -n 100 > /tmp/pisonet-logs.txt
uname -a > /tmp/system-info.txt
gpio readall > /tmp/gpio-status.txt

# Send these files to support
```

### Describe the Problem

Include:
1. What you were doing
2. What you expected to happen
3. What actually happened
4. Steps to reproduce
5. Error messages (exact text)
6. Log files

### Contact Support

Email with:
- Description of issue
- Log files
- Hardware/OS info
- Steps to reproduce

---

**Last Updated:** 2024-01-15  
**PisoNet Version:** 1.0.0
