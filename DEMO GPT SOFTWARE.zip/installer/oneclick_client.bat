@echo off
REM PisoNet Windows Client - One-Click Installer
REM Right-click this file and select "Run as Administrator"

setlocal enabledelayedexpansion

echo.
echo ======================================================
echo          ^|^| PisoNet Windows Client Installer
echo ======================================================
echo.

REM Check if running as administrator
net session >nul 2>&1
if %errorlevel% neq 0 (
    echo [ERROR] This script must be run as Administrator!
    echo Right-click this file and select "Run as Administrator"
    pause
    exit /b 1
)

REM Check Python installation
echo [1/6] Checking Python installation...
python --version >nul 2>&1
if errorlevel 1 (
    echo [ERROR] Python not found!
    echo Please download Python 3.8+ from https://www.python.org/downloads/
    echo Make sure to check "Add Python to PATH" during installation
    pause
    exit /b 1
)

for /f "tokens=*" %%i in ('python --version') do set PYTHON_VERSION=%%i
echo Found: !PYTHON_VERSION!

REM Create directories
echo [2/6] Creating application directories...
set APPDATA_PATH=%APPDATA%\PisoNet
mkdir "%APPDATA_PATH%" 2>nul
mkdir "%APPDATA_PATH%\logs" 2>nul
mkdir "C:\Program Files\PisoNet" 2>nul

REM Install Python dependencies
echo [3/6] Installing Python dependencies...
pip install -q PyQt5==5.15.9 requests==2.31.0
if errorlevel 1 (
    echo [ERROR] Failed to install dependencies
    pause
    exit /b 1
)

REM Download client script
echo [4/6] Downloading client application...
REM In production, download from your server
REM For now, create a minimal client
cd /d "%APPDATA_PATH%"
if not exist "pisonet_client.py" (
    echo # PisoNet Client will be installed here > pisonet_client.py
)

REM Create shortcut in Start Menu
echo [5/6] Creating shortcuts...
powershell -Command "^
$WshShell = New-Object -ComObject WScript.Shell
$DesktopPath = [Environment]::GetFolderPath('Desktop')
$Shortcut = $WshShell.CreateShortcut(\"$DesktopPath\PisoNet.lnk\")
$Shortcut.TargetPath = \"C:\Program Files\Python\python.exe\"
$Shortcut.Arguments = \"'%APPDATA_PATH%\pisonet_client.py'\"
$Shortcut.WorkingDirectory = \"%APPDATA_PATH%\"
$Shortcut.IconLocation = \"C:\Program Files\PisoNet\icon.ico\"
$Shortcut.Save()
" >nul 2>&1

REM Create config if not exists
echo [6/6] Setting up configuration...
if not exist "%APPDATA_PATH%\client_config.ini" (
    (
        echo [Server]
        echo server_ip = 192.168.1.100
        echo server_port = 5000
        echo server_hostname = pisonet.local
        echo.
        echo [Client]
        echo client_name = Workstation-1
        echo check_interval = 1
        echo.
        echo [UI]
        echo timer_x = 10
        echo timer_y = 10
        echo timer_width = 300
        echo timer_height = 150
        echo transparency = 0.9
    ) > "%APPDATA_PATH%\client_config.ini"
)

echo.
echo ======================================================
echo                ^|^| Installation Complete!
echo ======================================================
echo.
echo Configuration saved to:
echo   %APPDATA_PATH%
echo.
echo Desktop shortcut created!
echo.
echo Next steps:
echo   1. Edit server IP in %APPDATA_PATH%\client_config.ini
echo   2. Click the PisoNet shortcut on your desktop
echo   3. Client will connect to your server automatically
echo.
echo Server IP: Find it with: ping pisonet.local
echo.
pause
