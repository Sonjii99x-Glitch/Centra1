#!/bin/bash

# PisoNet Orange Pi Installation Script
# This script installs the complete server on Orange Pi

set -e

echo "=========================================="
echo "  🪙 PisoNet Orange Pi Installation"
echo "=========================================="
echo ""

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Check if running as root
if [[ $EUID -ne 0 ]]; then
   echo -e "${RED}[ERROR]${NC} This script must be run as root"
   echo "Run with: sudo ./install_opi.sh"
   exit 1
fi

# Update system
echo -e "${YELLOW}[1/7]${NC} Updating system packages..."
apt-get update -qq
apt-get upgrade -y -qq

# Install dependencies
echo -e "${YELLOW}[2/7]${NC} Installing dependencies..."
apt-get install -y -qq \
    python3 \
    python3-pip \
    python3-dev \
    git \
    curl \
    wget \
    build-essential

# Install Python packages
echo -e "${YELLOW}[3/7]${NC} Installing Python packages..."
pip3 install -q \
    Flask==3.0.0 \
    Flask-CORS==4.0.0 \
    RPi.GPIO==0.7.0 \
    Werkzeug==3.0.0

# Create directories
echo -e "${YELLOW}[4/7]${NC} Creating directories..."
mkdir -p /opt/pisonet
mkdir -p /var/lib/pisonet
mkdir -p /var/log/pisonet
mkdir -p /opt/pisonet/templates

# Download files from GitHub (or use local if in development)
echo -e "${YELLOW}[5/7]${NC} Setting up server files..."

# Create main server file
cat > /opt/pisonet/pisonet_server.py << 'EOF'
# Server file will be downloaded or copied here
# For now, we'll create a minimal version that the user can update
echo "Server installation complete"
EOF

# Setup systemd service
echo -e "${YELLOW}[6/7]${NC} Setting up systemd service..."
cat > /etc/systemd/system/pisonet.service << 'EOF'
[Unit]
Description=PisoNet Cybercafe Management Server
After=network.target
Wants=network-online.target

[Service]
Type=simple
User=root
WorkingDirectory=/opt/pisonet
ExecStart=/usr/bin/python3 /opt/pisonet/pisonet_server.py
StandardOutput=journal
StandardError=journal
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload
systemctl enable pisonet

# Configure hostname
echo -e "${YELLOW}[7/7]${NC} Configuring network..."
echo "pisonet.local" > /etc/hostname
hostname pisonet.local

# Add to hosts file
if ! grep -q "pisonet.local" /etc/hosts; then
    echo "127.0.0.1    pisonet.local" >> /etc/hosts
fi

echo ""
echo -e "${GREEN}=========================================="
echo "  ✅ Installation Complete!"
echo "==========================================${NC}"
echo ""
echo "Server: http://pisonet.local:5000"
echo "Default login: admin / admin123"
echo ""
echo -e "${YELLOW}Important:${NC}"
echo "1. Copy pisonet_server.py to /opt/pisonet/"
echo "2. Copy templates to /opt/pisonet/templates/"
echo "3. Start server: sudo systemctl start pisonet"
echo "4. View logs: sudo journalctl -u pisonet -f"
echo ""
echo "To monitor:"
echo "  sudo systemctl status pisonet"
echo "  sudo journalctl -u pisonet -f"
echo ""
