#!/usr/bin/env python3
"""
PisoNet Universal One-Click Installer
Works on Windows, Mac, and Linux
"""

import os
import sys
import subprocess
import platform
import socket
import json
from pathlib import Path
from configparser import ConfigParser

# ============================================================================
# COLORS FOR TERMINAL
# ============================================================================

class Colors:
    HEADER = '\033[95m'
    BLUE = '\033[94m'
    CYAN = '\033[96m'
    GREEN = '\033[92m'
    YELLOW = '\033[93m'
    RED = '\033[91m'
    ENDC = '\033[0m'
    BOLD = '\033[1m'
    UNDERLINE = '\033[4m'

    @staticmethod
    def disable():
        Colors.HEADER = ''
        Colors.BLUE = ''
        Colors.CYAN = ''
        Colors.GREEN = ''
        Colors.YELLOW = ''
        Colors.RED = ''
        Colors.ENDC = ''
        Colors.BOLD = ''
        Colors.UNDERLINE = ''

# Disable colors on Windows if not supported
if platform.system() == 'Windows':
    try:
        import colorama
        colorama.init()
    except:
        Colors.disable()

# ============================================================================
# CONFIGURATION
# ============================================================================

def get_appdata_path():
    """Get platform-specific appdata path"""
    if platform.system() == 'Windows':
        return Path(os.environ.get('APPDATA')) / 'PisoNet'
    elif platform.system() == 'Darwin':  # macOS
        return Path.home() / 'Library' / 'Application Support' / 'PisoNet'
    else:  # Linux
        return Path.home() / '.config' / 'PisoNet'

# ============================================================================
# UTILITIES
# ============================================================================

def print_header(text):
    print(f"\n{Colors.BOLD}{Colors.BLUE}{'='*70}{Colors.ENDC}")
    print(f"{Colors.BOLD}{Colors.BLUE}  {text}{Colors.ENDC}")
    print(f"{Colors.BOLD}{Colors.BLUE}{'='*70}{Colors.ENDC}\n")

def print_success(text):
    print(f"{Colors.GREEN}✓ {text}{Colors.ENDC}")

def print_error(text):
    print(f"{Colors.RED}✗ {text}{Colors.ENDC}")

def print_info(text):
    print(f"{Colors.CYAN}ℹ {text}{Colors.ENDC}")

def print_warning(text):
    print(f"{Colors.YELLOW}⚠ {text}{Colors.ENDC}")

def run_command(cmd, description=""):
    """Run shell command"""
    if description:
        print_info(description)
    try:
        result = subprocess.run(cmd, shell=True, capture_output=True, text=True)
        if result.returncode == 0:
            if description:
                print_success(description)
            return True
        else:
            if description:
                print_error(f"{description} (exit code: {result.returncode})")
            return False
    except Exception as e:
        if description:
            print_error(f"{description}: {e}")
        return False

# ============================================================================
# INSTALLER COMPONENTS
# ============================================================================

class PisoNetInstaller:
    def __init__(self):
        self.appdata_path = get_appdata_path()
        self.os_type = platform.system()
        self.python_version = platform.python_version()

    def print_banner(self):
        """Print welcome banner"""
        print_header("🪙 PisoNet Universal Installer v1.0")
        print(f"{Colors.CYAN}Platform: {self.os_type}")
        print(f"Python: {self.python_version}")
        print(f"AppData: {self.appdata_path}{Colors.ENDC}\n")

    def menu(self):
        """Show installation menu"""
        while True:
            print_header("PisoNet Installation Menu")
            print("What would you like to do?\n")
            print("1) Install Windows Client")
            print("2) Setup Orange Pi Server (SSH)")
            print("3) Install on This Machine (Server)")
            print("4) View Configuration")
            print("5) Find Server on Network")
            print("6) Open Admin Dashboard")
            print("7) Exit\n")

            choice = input(f"{Colors.YELLOW}Enter choice (1-7): {Colors.ENDC}").strip()

            if choice == '1':
                self.install_client()
            elif choice == '2':
                self.install_opi_ssh()
            elif choice == '3':
                self.install_server()
            elif choice == '4':
                self.view_config()
            elif choice == '5':
                self.find_server()
            elif choice == '6':
                self.open_dashboard()
            elif choice == '7':
                print_success("Goodbye!")
                break
            else:
                print_error("Invalid choice")

    def install_client(self):
        """Install Windows client"""
        print_header("Installing PisoNet Client")

        # Check Python
        print_info("Checking Python installation...")
        if not run_command("python --version"):
            print_error("Python not found! Install from https://www.python.org/")
            input("Press Enter to continue...")
            return

        print_success("Python found")

        # Create directories
        print_info(f"Creating directories at {self.appdata_path}...")
        self.appdata_path.mkdir(parents=True, exist_ok=True)
        print_success("Directories created")

        # Install dependencies
        print_info("Installing Python dependencies...")
        if run_command("pip install -q PyQt5 requests"):
            print_success("Dependencies installed")
        else:
            print_warning("Some dependencies may have failed")

        # Create config
        self.create_default_config()

        print_success("Client installation complete!")
        print_info(f"Configuration saved to: {self.appdata_path}")
        print_info(f"Edit 'client_config.ini' to set server IP")
        input("\nPress Enter to continue...")

    def install_server(self):
        """Install server on this machine"""
        print_header("Installing PisoNet Server")

        if self.os_type == 'Windows':
            print_error("Server installation on Windows not recommended")
            print_info("For Windows development, use WSL2 or Virtual Machine")
            input("Press Enter to continue...")
            return

        if self.os_type != 'Linux':
            print_error("Server installation only supported on Linux/Raspberry Pi")
            input("Press Enter to continue...")
            return

        # Check sudo
        print_info("Checking sudo access...")
        if not run_command("sudo -n true", ""):
            print_error("Sudo access required")
            input("Press Enter to continue...")
            return

        # Install dependencies
        print_info("Installing system packages...")
        run_command("sudo apt-get update -qq && sudo apt-get install -y python3 python3-pip",
                   "Installing packages")

        # Install Python packages
        print_info("Installing Python packages...")
        run_command("sudo pip3 install Flask Flask-CORS RPi.GPIO",
                   "Installing Flask and GPIO")

        # Create directories
        print_info("Creating server directories...")
        run_command("sudo mkdir -p /opt/pisonet /var/lib/pisonet /var/log/pisonet",
                   "Creating directories")

        # Setup service
        print_info("Setting up systemd service...")
        run_command("sudo systemctl daemon-reload",
                   "Reloading systemd")

        print_success("Server installation complete!")
        print_warning("Manual steps required:")
        print("1. Copy server files to /opt/pisonet/")
        print("2. Start service: sudo systemctl start pisonet")
        print("3. View logs: sudo journalctl -u pisonet -f")
        input("\nPress Enter to continue...")

    def install_opi_ssh(self):
        """Install on Orange Pi via SSH"""
        print_header("PisoNet Orange Pi Installation via SSH")

        # Get Orange Pi details
        print("\n" + Colors.CYAN + "Orange Pi Connection Details" + Colors.ENDC)
        hostname = input("Orange Pi hostname or IP (default: pisonet.local): ").strip()
        if not hostname:
            hostname = "pisonet.local"

        username = input("Username (default: pi): ").strip()
        if not username:
            username = "pi"

        # Test connection
        print_info(f"Testing SSH connection to {username}@{hostname}...")
        if not run_command(f"ssh -o ConnectTimeout=5 {username}@{hostname} 'echo OK'", ""):
            print_error("Cannot connect to Orange Pi")
            print_info("Make sure:")
            print("  1. Orange Pi is on the network")
            print("  2. SSH is enabled")
            print("  3. Username and hostname are correct")
            input("Press Enter to continue...")
            return

        print_success("Connection successful!")

        # Run installation script
        print_info("Running installation script on Orange Pi...")
        print_warning("This may take 5-10 minutes...")

        install_script = """
sudo apt-get update -qq
sudo apt-get install -y python3-pip git
sudo pip3 install Flask Flask-CORS RPi.GPIO
sudo mkdir -p /opt/pisonet /var/lib/pisonet /var/log/pisonet
sudo systemctl daemon-reload
echo "✅ Installation complete!"
"""

        run_command(f"ssh {username}@{hostname} '{install_script}'",
                   "Installing on Orange Pi")

        print_success("Orange Pi installation complete!")
        print_info("Next steps:")
        print("  1. Copy server files via SCP")
        print("  2. ssh into Orange Pi and start service")
        input("\nPress Enter to continue...")

    def create_default_config(self):
        """Create default configuration file"""
        config_file = self.appdata_path / 'client_config.ini'
        config = ConfigParser()

        config['Server'] = {
            'server_ip': '192.168.1.100',
            'server_port': '5000',
            'server_hostname': 'pisonet.local'
        }
        config['Client'] = {
            'client_name': f'Workstation-1',
            'check_interval': '1'
        }
        config['UI'] = {
            'timer_x': '10',
            'timer_y': '10',
            'timer_width': '300',
            'timer_height': '150',
            'transparency': '0.9'
        }

        self.appdata_path.mkdir(parents=True, exist_ok=True)
        with open(config_file, 'w') as f:
            config.write(f)

    def view_config(self):
        """View configuration"""
        print_header("Configuration")

        config_file = self.appdata_path / 'client_config.ini'
        if config_file.exists():
            print(f"Location: {config_file}\n")
            with open(config_file, 'r') as f:
                print(f.read())
        else:
            print_warning("No configuration found yet")
            print_info("Run 'Install Client' first")

        input("\nPress Enter to continue...")

    def find_server(self):
        """Find server on network"""
        print_header("Finding PisoNet Server")

        print_info("Pinging pisonet.local...")
        run_command("ping -c 1 pisonet.local" if self.os_type != 'Windows' else "ping -n 1 pisonet.local",
                   "")

        try:
            ip = socket.gethostbyname('pisonet.local')
            print_success(f"Server found at: {ip}")
            print_info(f"Admin Dashboard: http://{ip}:5000")
        except:
            print_warning("Server not found")
            print_info("Make sure server is running and on the network")

        input("\nPress Enter to continue...")

    def open_dashboard(self):
        """Open admin dashboard"""
        print_header("Opening Admin Dashboard")

        try:
            ip = socket.gethostbyname('pisonet.local')
            url = f'http://{ip}:5000'
            print_info(f"Opening {url}...")

            if self.os_type == 'Darwin':
                os.system(f'open "{url}"')
            elif self.os_type == 'Windows':
                os.system(f'start {url}')
            else:
                os.system(f'xdg-open "{url}"')

            print_success("Dashboard opened in browser")
        except:
            print_error("Cannot resolve pisonet.local")
            print_info("Try accessing: http://192.168.x.x:5000")

        input("\nPress Enter to continue...")

# ============================================================================
# MAIN
# ============================================================================

if __name__ == '__main__':
    try:
        installer = PisoNetInstaller()
        installer.print_banner()
        installer.menu()
    except KeyboardInterrupt:
        print(f"\n{Colors.YELLOW}Installation cancelled{Colors.ENDC}")
        sys.exit(0)
    except Exception as e:
        print(f"\n{Colors.RED}Error: {e}{Colors.ENDC}")
        sys.exit(1)
