@echo off
REM PisoNet Master Installer
REM Complete installation for server and clients

setlocal enabledelayedexpansion

cls
echo.
echo ============================================================================
echo                    🪙 PisoNet Master Installer v1.0
echo          Complete Cybercafe Management System Installation
echo ============================================================================
echo.

REM Check admin rights
net session >nul 2>&1
if errorlevel 1 (
    echo [ERROR] This script requires Administrator privileges
    echo Right-click and select "Run as Administrator"
    pause
    exit /b 1
)

:menu
cls
echo.
echo ============================================================================
echo                           PisoNet Installation Menu
echo ============================================================================
echo.
echo Select what to install:
echo.
echo  1) Install Windows Client Only
echo  2) Install License Manager
echo  3) View Configuration
echo  4) Get Server IP
echo  5) Open Admin Dashboard
echo  6) Exit
echo.
set /p choice="Enter your choice (1-6): "

if "%choice%"=="1" goto install_client
if "%choice%"=="2" goto install_license
if "%choice%"=="3" goto view_config
if "%choice%"=="4" goto get_server
if "%choice%"=="5" goto open_dashboard
if "%choice%"=="6" exit /b 0

echo Invalid choice
pause
goto menu

:install_client
cls
echo.
echo [Step 1] Installing Windows Client...
echo.

REM Check Python
python --version >nul 2>&1
if errorlevel 1 (
    echo [ERROR] Python not found!
    echo Please install Python 3.8+ from https://www.python.org/downloads/
    pause
    goto menu
)

REM Install dependencies
echo Installing dependencies...
pip install -q PyQt5==5.15.9 requests==2.31.0

REM Create directories
set APPDATA_PATH=%APPDATA%\PisoNet
mkdir "%APPDATA_PATH%" 2>nul

REM Create config
if not exist "%APPDATA_PATH%\client_config.ini" (
    echo Creating configuration file...
    (
        echo [Server]
        echo server_ip = 192.168.1.100
        echo server_port = 5000
        echo server_hostname = pisonet.local
        echo.
        echo [Client]
        echo client_name = Workstation-1
        echo check_interval = 1
    ) > "%APPDATA_PATH%\client_config.ini"
)

echo.
echo ✅ Client installation complete!
echo Configuration: %APPDATA_PATH%\client_config.ini
echo.
pause
goto menu

:install_license
cls
echo.
echo [Step 2] Setting up License Manager...
echo.
echo To activate your license:
echo.
echo 1. Open your server admin dashboard
echo 2. Go to: http://pisonet.local:5000/license
echo 3. Click "Activate Online"
echo 4. Done!
echo.
pause
goto menu

:view_config
cls
echo.
echo Configuration Files:
echo.
set APPDATA_PATH=%APPDATA%\PisoNet
if exist "%APPDATA_PATH%\client_config.ini" (
    echo Found: %APPDATA_PATH%\client_config.ini
    echo.
    type "%APPDATA_PATH%\client_config.ini"
) else (
    echo No configuration found yet
)
echo.
pause
goto menu

:get_server
cls
echo.
echo Finding server on network...
echo.
echo Trying: ping pisonet.local
ping pisonet.local
echo.
pause
goto menu

:open_dashboard
cls
echo.
echo Opening admin dashboard...
echo URL: http://pisonet.local:5000
echo.
start http://pisonet.local:5000
timeout /t 2 >nul
goto menu

:end
pause
